subject_data_list <- list()

# Loop through each subject
for (subject_id in unique(movement_data$subject)) {
  subject_df <- movement_data %>%
    filter(subject == subject_id)
  
  num_trials <- max(subject_df$trial)  # Get the maximum trial number for the subject
  
  
  # Initialize lists for each trial's data
  trials_data <- vector("list", length = num_trials)
  frames_data <- vector("list", length = num_trials)
  cursor_data <- vector("list", length = num_trials)
  target_data <- vector("list", length = num_trials)
  
  # Extract and organize data for each trial
  for (trial_num in 1:num_trials) {
    trial <- subject_df %>%
      filter(trial == trial_num)
    
    trials_data[[trial_num]] <- list(
      is_manipulated = trial$is_manipulated[1],
      manipulation_angle = trial$manipulation_angle[1],
      manipulation_type = trial$manipulation_type[1],
      jump_angle = trial$jump_angle[1],
      online_feedback = trial$online_feedback[1],
      endpoint_feedback = trial$endpoint_feedback[1],
      was_restarted = trial$was_restarted[1],
      is_judged = trial$is_judged[1],
      too_slow = trial$too_slow[1], 
      rt = trial$rt[1],
      mt = trial$mt[1],
      ep_reach_angle = trial$reach_angle[1],
      diff_angle = trial$diff_angle[1],
      response = trial$response[1],
      response_time = trial$response_time[1],
      correct_response = trial$correct_response[1],
      correct_flag = trial$correct_flag[1]
    )
    
    frames_data[[trial_num]] <- list(
      framecount = length(trial$frames),
      start_state = "REACH",
      end_state = "DIST_EXCEEDED",
      frame_comp_dur = trial$frame_dur
    )
    
    cursor_data[[trial_num]] <- list(
      x = trial$x,
      y = trial$y,
      vis = trial$vis,
      label = trial$label
    )
    
    target_data[[trial_num]] <- list(
      x = trial$target_x[1],
      y = trial$target_y[1],
      angle = trial$target_angle[1]
    )
  }
  
  # Combine the trials' data into a sublist for the subject
  subject_data <- list(
    trials = trials_data,
    frames = frames_data,
    cursor = cursor_data,
    target = target_data
  )
  
  subject_data_list[[as.character(subject_id)]] <- subject_data
}
