library(jsonlite)
library(stringi)
library(lubridate)

# Assuming dat_temp is your data frame
subject_ids <- unique(dat_temp$subject)
# Initial datetime setup
start_datetime <- ymd_hms("2023-12-07 09:00:23")

for (subject_id_index in seq_along(subject_ids)) {
  subject_id <- subject_ids[subject_id_index]
  subject_data <- subject_data_list[[subject_id_index]]
  # Other block-level information setup
# Calculate the next start datetime based on conditions
if (hour(start_datetime) >= 17 && minute(start_datetime) >= 30) {
# Move to the next day after 17:30:00
start_datetime <- start_datetime + days(1)
if (subject_id > 1) {
# Adjust start datetime for the remaining subjects after the first one
start_datetime <- start_datetime + hours(9) + minutes(3) + seconds(2)
}
} else {
# Increment datetime by mean 30mins, sd 1 minute, 3 seconds
start_datetime <- start_datetime + as.difftime(rnorm(1, mean = 1800, sd = 60), units = "secs")
start_datetime <- start_datetime + as.difftime(rnorm(1, mean = 60, sd = 3), units = "secs")
}
block_category <- toJSON(list(
block = list(
id = paste0(subject_id),
is_debug = FALSE,
git_hash = "782cdaa18f860196d54401a952c60c27526e700c",
sysinfo = list(
sysname = 'Linux',
nodename = "minnith-desktop",
release = '5.15.0-89-lowlatency',
version = '#99~20.04.1-Ubuntu SMP PREEMPT Thu Nov 2 15:19:30: UTC 2023',
machine = 'x86_64',
oct_ver = "5.2.0"
),
ptb_ver = list(
major = 3,
minor = 0,
point = 18,
string = '3.0.18 - Flavor: beta - Corresponds to SVN Revision 12737\nFor more info visit: ...',
flavor = 'beta',
revision = '12737',
revstring = ' Corresponds to SVN Revision 12737',
websvn = 'https://github.com/Psychtoolbox-3/Psychtoolbox-3'
),
gpu_vendor = "AMD",
gpu_renderer = "AMD DIMGREY_CAVEFISH (DRM 3.42.0, 5.15.0-69-lowlatency, LLVM 12.0.0)",
gl_version = "4.6 (Compatibility Profile) Mesa 21.2.6",
missed_deadlines = rnorm(1, mean = 37756, sd = 20),
n_flips = rnorm(1, mean = 83239, sd = 20),
start_dt = format(start_datetime, "%Y-%m-%d %H:%M:%S"),
state_names = c('END', 'RETURN_TO_CENTER', 'REACH', 'DIST_EXCEED', 'BAD_MOVEMENT', 'FEEDBACK', 'CURSOR_JUMP', 'JUDGE'),
trial_labels = c('PRACTICE1', 'PRACTICE2', 'BASELINE', 'BASELINE_AIM', 'PERTURBATION', 'WASHOUT'),
manip_labels = c('NONE', 'CLAMP', 'ROTATION'),
cursor = list(
size = 4,
color = c(255, 255, 255)
),
center = list(
size = 8,
color = c(77, 77, 77)
),
offset = list(
x = 0,
y = 40
),
target = list(
size = 8,
color1 = c(0, 255, 0),
color2 = c(0, 255, 0),
distance = 75
),
off_color = c(0, 255, 0),
judge = list(
thickness = 20,
color = c(0, 180, 0),
default_width = 50,
rot_or_clamp = 'rot',
feedback_duration = 0.3
),
max_mt = 0.6,
max_rt = 0.6,
exp_info = 'PP_VMR_v1',
block_type = 'r',
seed = c(109, 112, 109, 54, 53),
exp_version = 'v1',
manipulation_angle = 0
),
subject_data = subject_data  # Insert subject-specific data here from subject_data_list
), auto_unbox = TRUE, pretty = TRUE)
# Merge categories into a single JSON
final_json <- paste0("{", block_category, ",", trial_category, " ")
# Generate random numbers, define file name, and write JSON data to a file
random_numbers <- stri_rand_strings(1, 4, '[0-9]')
file_name <- paste0(subject_id, "_", '168149', random_numbers, ".json")
writeLines(final_json, file(file_name))
}
