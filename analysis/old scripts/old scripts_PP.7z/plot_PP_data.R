# Create a vector with 5000 zeros
vec_zeros <- rep(0, 5000)

# Create a vector with 2500 -4's and 2500 4's
vec_minus_4 <- rep(-4, 2500)
vec_4 <- rep(4, 2500)

# Combine the zeros, -4's, and 4's vectors
combined_vec <- c(vec_zeros, vec_minus_4, vec_4)

# Shuffle the combined vector
shuffled_combined_vec <- sample(combined_vec)

# Create a vector with 5000 1's and 5000 -1's
vec_ones <- rep(1, 5000)
vec_minus_ones <- rep(-1, 5000)

# Combine the vectors of 1's and -1's
combined_vec_ones <- c(vec_ones, vec_minus_ones)

# Shuffle the combined vector of 1's and -1's
shuffled_combined_vec_ones <- sample(combined_vec_ones)

# Display the shuffled vectors
cat("Shuffled Vector with Zeros, -4s, and 4s:\n")
print(shuffled_combined_vec)

cat("\nShuffled Vector with 1s and -1s:\n")
print(shuffled_combined_vec_ones)



# Create a vector of zeros
vector1 <- rep(0, 10000)

# Set the mean probabilities
mean_probabilities <- c(0.83, 0.76, 0.85, 0.75, 0.6, 0.61)

# Create the subject vector
subjects <- rep(1:20, each = 500)

# Generate individual probabilities for each subject based on means and individual SDs
subject_probabilities <- sapply(1:length(subjects), function(i) {
  probs <- rnorm(length(mean_probabilities), mean = mean_probabilities, sd = 0.003)
  probs[probs > 0.99] <- 0.99  # Cap probabilities at 99%
  probs[probs < 0] <- 0  # Ensure probabilities don't go below 0
  probs
})

# Ensure probabilities stay within [0, 1]
subject_probabilities[subject_probabilities > 1] <- 1

# Iterate through indices
for (i in 1:length(vector1)) {
  if (shuffled_combined_vec_ones[i] == 1 && shuffled_combined_vec[i] == 4) {
    vector1[i] <- rbinom(1, 1, subject_probabilities[1, subjects[i]])
  } else if (shuffled_combined_vec_ones[i] == -1 && shuffled_combined_vec[i] == 4) {
    vector1[i] <- rbinom(1, 1, subject_probabilities[2, subjects[i]])
  } else if (shuffled_combined_vec_ones[i] == -1 && shuffled_combined_vec[i] == -4) {
    vector1[i] <- rbinom(1, 1, subject_probabilities[3, subjects[i]])
  } else if (shuffled_combined_vec_ones[i] == 1 && shuffled_combined_vec[i] == -4) {
    vector1[i] <- rbinom(1, 1, subject_probabilities[4, subjects[i]])
  } else if (shuffled_combined_vec_ones[i] == -1 && shuffled_combined_vec[i] == 0) {
    vector1[i] <- rbinom(1, 1, subject_probabilities[5, subjects[i]])
  } else if (shuffled_combined_vec_ones[i] == 1 && shuffled_combined_vec[i] == 0) {
    vector1[i] <- rbinom(1, 1, subject_probabilities[6, subjects[i]])
  }
}

# Display vector1
print(vector1)


dat_temp$correct_flag = vector1

# Assuming 'correct_flag' is a column in the 'dat' dataframe

# Change values based on condition
dat_temp$correct_flag <- ifelse(dat_temp$correct_flag == 0, 'incorrect', 'correct')

# Display the updated column
print(dat_temp$correct_flag)


dat_temp$response <- ifelse(dat_temp$correct_flag == 'correct', dat_temp$correct_response,
                       ifelse(dat_temp$correct_flag == 'incorrect' & dat_temp$correct_response == 'right', 'left',
                              ifelse(dat_temp$correct_flag == 'incorrect' & dat_temp$correct_response == 'left', 'right', NA)))


# Display a preview of the updated dat dataframe
head(dat_temp)



# Calculate mean and standard deviation of probabilities per subject
subject_prob_stats <- sapply(1:20, function(s) {
  subject_indices <- which(subjects == s)
  subject_probs <- subject_probabilities[, subject_indices]
  subject_probs_mean <- apply(subject_probs, 1, mean)
  subject_probs_sd <- apply(subject_probs, 1, sd)
  
  data.frame(
    Subject = s,
    Mean_Probabilities = subject_probs_mean,
    SD_Probabilities = subject_probs_sd
  )
})

# Display statistics for each subject
subject_prob_stats



# Calculate counts of correct and incorrect responses including subject numbers
response_counts <- dat %>%
  group_by(subject, manip_angle, jump_angle, correct_flag) %>%
  summarize(count = n()) %>%
  ungroup()

# Calculate the total count for each (subject, manip_angle, jump_angle, target_angle) combination
total_counts <- response_counts %>%
  group_by(subject, manip_angle, jump_angle) %>%
  summarize(total_count = sum(count))

# Calculate the percentage of correct responses for each subject
percentage_correct <- response_counts %>%
  filter(correct_flag == 1) %>%
  left_join(total_counts, by = c("subject", "manip_angle", "jump_angle")) %>%
  mutate(percentage_correct = (count / total_count) * 100)

# Calculate mean and standard deviation of correct and incorrect responses including subject numbers
response_stats <- dat %>%
  group_by(manip_angle, jump_angle) %>%
  summarise(mean_correct = mean(correct_flag == 1),
            sd_correct = sd(correct_flag == 1),
            mean_incorrect = mean(correct_flag == 0),
            sd_incorrect = sd(correct_flag == 0))

# Display the calculated statistics
print(response_stats)


# Load necessary library
library(ggplot2)

# Plot mean percentage correct with error bars
ggplot(response_stats, aes(x = jump_angle, y = mean_correct, group = manip_angle, color = as.factor(manip_angle))) +
  geom_errorbar(aes(ymin = mean_correct - sd_correct, ymax = mean_correct + sd_correct), width = 0.2) +
  geom_point(position = position_dodge(width = 0.3), size = 3, shape = 21, fill = "white") +
  labs(x = "Jump Angle", y = "Mean Percentage Correct") +
  theme_minimal() +
  theme(legend.position = "top")


