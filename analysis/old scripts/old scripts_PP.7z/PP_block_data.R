library(jsonlite)
library(stringi)
library(lubridate)

# Assuming dat_temp is your data frame
subject_ids <- unique(dat_temp$subject)

# Initial DateTime Setup for the first day
start_datetime_day1 <- ymd_hms("2023-12-07 09:01:23")

# Initial DateTime Setup for the second day starting at 09:05:12
start_datetime_day2 <- ymd_hms("2023-12-08 09:05:12")

# Initialize an empty list to store block data
block_data <- list()

for (i in 1:length(subject_ids)) {
  subject_id <- subject_ids[i]
  
  if (i <= 10) {
    # For subjects 1-10, set the start time on 2023-12-07
    start_datetime <- start_datetime_day1 + minutes((i - 1) * 30)
  } else {
    # For subjects 11-20, set the start time on 2023-12-08
    start_datetime <- start_datetime_day2 + minutes((i - 11) * 30)
  }
  
  # Store start_dt for each subject_id
  subject_start_dt <- format(start_datetime, "%Y-%m-%d %H:%M:%S")
  
  # Create the block category with updated start_dt
  block_category <- toJSON(list(
    block = list(
      id = paste0("ms", subject_id),
      is_debug = FALSE,  
      git_hash = "782cdaa18f860196d54401a952c60c27526e700c",  
      sysinfo = list(
        sysname = 'Linux',
        nodename = "minnith-desktop",
        release = '5.15.0-89-lowlatency',
        version = '#99~20.04.1-Ubuntu SMP PREEMPT Thu Nov 2 15:19:30: UTC 2023',
        machine = 'x86_64',
        oct_ver = "5.2.0"
      ),
      ptb_ver = list(
        major = 3,
        minor = 0,
        point = 18,
        string = '3.0.18 - Flavor: beta - Corresponds to SVN Revision 12737\nFor more info visit: ...',
        flavor = 'beta',
        revision = '12737',
        revstring = ' Corresponds to SVN Revision 12737',
        websvn = 'https://github.com/Psychtoolbox-3/Psychtoolbox-3'
      ),
      # Other block-level information...
      start_dt = format(start_datetime, "%Y-%m-%d %H:%M:%S"),
      state_names = c('END', 'RETURN_TO_CENTER', 'REACH', 'DIST_EXCEED', 'BAD_MOVEMENT', 'FEEDBACK', 'CURSOR_JUMP', 'JUDGE'),
      trial_labels = c('PRACTICE1', 'PRACTICE2', 'BASELINE', 'BASELINE_AIM', 'PERTURBATION', 'WASHOUT'),
      manip_labels = c('NONE', 'CLAMP', 'ROTATION'),
      cursor = list(
        size = 4,
        color = c(255, 255, 255)
      ),
      center = list(
        size = 8,
        color = c(77, 77, 77)
      ),
      offset = list(
        x = 0,
        y = 40
      ),
      target = list(
        size = 8,
        color1 = c(0, 255, 0),
        color2 = c(0, 255, 0),
        distance = 75
      ),
      off_color = c(0, 255, 0),
      judge = list(
        thickness = 20,
        color = c(0, 180, 0),
        default_width = 50,
        rot_or_clamp = 'rot',
        feedback_duration = 0.3
      ),
      max_mt = 0.6,
      max_rt = 0.6,
      exp_info = 'PP_VMR_v1',
      block_type = 'r',
      seed = c(109, 112, 109, 54, 53),
      exp_version = 'v1',
      manipulation_angle = 0    )
  ), auto_unbox = TRUE, pretty = TRUE)
  
  # Append block_category to the list with subject_id as the key
  block_data[[paste0(subject_id)]] <- block_category
  }


# Access block data for a specific subject (e.g., subject_1)
block_for_subject_1 <- block_data[["subject_1"]]
