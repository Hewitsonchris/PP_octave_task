combined_data_list <- list()  # Initialize an empty list to store combined data

for (index in seq_along(block_category)) {
  combined_data <- list(
    block_category = block_category[[index]],
    subject_data = subject_data_list[[index]]
  )
  
  combined_data_list[[index]] <- combined_data
}

# Now, combined_data_list contains the combined data from block_category and subject_data_list at each index
combined_data_list <- list()  # Initialize an empty list to store combined data

for (index in seq_along(block_category)) {
  combined_data <- list(
    block = block_category[[index]],
    trials = subject_data_list[[index]]$trials,
    frames = subject_data_list[[index]]$frames,
    cursor = subject_data_list[[index]]$cursor,
    target = subject_data_list[[index]]$target
  )
  
  combined_data_list[[index]] <- combined_data
}
library(stringi)
library(jsonlite)

for (index in seq_along(combined_data_list)) {
  subject_data <- combined_data_list[[index]]
  subject_id <- subject_data$block$id
  
  # Create a combined object for all data
  combined_subject_data <- list(
    block = subject_data$block,
    trials = subject_data$trials,
    frames = subject_data$frames,
    cursor = subject_data$cursor,
    target = subject_data$target
  )
  
  # Generate random numbers for filename
  random_numbers <- stri_rand_strings(1, 4, '[0-9]')
  
  # Save combined data to a compressed JSON file with modified filename
  subject_filename <- paste0(subject_id, "_", '168151', random_numbers, ".json.gz")
  subject_file <- gzfile(subject_filename, "wb")
  
  subject_json <- toJSON(combined_subject_data, pretty = TRUE)
  writeLines(subject_json, subject_file)
  close(subject_file)
}


