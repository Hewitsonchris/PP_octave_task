intention <- read.csv("TEST.csv")

intention$target_angle_mod <- intention$target_angle
 

# Assuming your dataframe is named 'intention'
diff_angle <- intention$diff_angle



# Recalculate reach_angle
intention$reach_angle_mod <- intention$hand_angle


intention$diff_angle_mod <- intention$target_angle_mod + intention$reach_angle_mod



# Assuming your dataframe is named 'intention'
intention$end_x_mod <- 75 * sin((intention$reach_angle_mod) * pi / 180)
intention$end_y_mod <- 75 * cos((intention$reach_angle_mod) * pi / 180)


# Create mid_angle using a loop
for (i in 1:nrow(intention)) {
  intention$mid_angle_mod[i] <- intention$reach_angle_mod[i] + rnorm(1, mean = 0, sd = 1)
}



# Assuming your dataframe is named 'intention'
intention$target_x_mod <- 75 * sin((intention$target_angle_mod) * pi / 180)
intention$target_y_mod <- 75 * cos((intention$target_angle_mod) * pi / 180)


# Assuming your dataframe is named 'intention'
intention$mid_x_mod <- (75/2) * sin((intention$mid_angle_mod) * pi / 180)
intention$mid_y_mod <- (75/2) * cos((intention$mid_angle_mod) * pi / 180)


# Assuming your dataframe is named 'intention'
selected_columns <- intention[, c("subject", "trial","mt","target_x_mod","target_y_mod" ,"mid_x_mod", "mid_y_mod", "end_x_mod", "end_y_mod")]

# Save to CSV
write.csv(selected_columns, "PP_TEST.csv", row.names = FALSE)