
dat$correct_flag = vector1

# Assuming 'correct_flag' is a column in the 'dat' dataframe

# Change values based on condition
dat$correct_flag <- ifelse(dat$correct_flag == 0, 'incorrect', 'correct')

# Display the updated column
print(dat$correct_flag)


dat$response <- ifelse(dat$correct_flag == 'correct', dat$correct_response,
                       ifelse(dat$correct_flag == 'incorrect' & dat$correct_response == 'right', 'left',
                              ifelse(dat$correct_flag == 'incorrect' & dat$correct_response == 'left', 'right', NA)))


# Display a preview of the updated dat dataframe
head(dat)


